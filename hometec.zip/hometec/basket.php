<?php
include("db.php");
$pagename="Smart Basket"; //Create and populate a variable called $pagename

echo "<link rel=stylesheet type=text/css href=mystylesheet.css>"; //Call in stylesheet

echo "<title>".$pagename."</title>"; //display name of the page as window title

echo "<body>";

include ("headfile.html"); //include header layout file 

echo "<h4>".$pagename."</h4>"; //display name of the page on the web page

if (isset($_POST['del_prodid']))
{
    //capture the posted product id and assign it to a local variable $delprodid
    $delprodid=$_POST['del_prodid'];
    //unset the cell of the session for this posted product id variable
    unset ($_SESSION['basket'][$delprodid]);
    //display a "1 item removed from the basket" message
    echo "<p>1 item removed from the basket";
}

if(isset($_POST["h_prodid"]))
{
    $newprodid=$_POST["h_prodid"];
    $requantity=$_POST["p_quantity"];
    //echo "<p>Selected product Id: ".$newprodid;
    //echo "<p>Selected Quantity: ".$requantity;

    //create a new cell in the basket session array. Index this cell with the new product id.
    //Inside the cell store the required product quantity
    $_SESSION['basket'][$newprodid]=$requantity;
    //echo "<p>1 item added";
}else{
    //echo "<p> Basket unchanged";
}

$total = 0;

//Create HTML table with header to display the content of the basket: prod name, price, selected quantity and subtotal
echo "<p><table id='baskettable'>";
echo "<tr>";
echo "<th>Product Name</th><th>Price</th><th>Quantity</th><th>Subtotal</th><th>Remove Product</th>";
echo "</tr>";

//if the session array $_SESSION['basket'] is set
if(isset($_SESSION['basket']))
{
    //loop through the basket session array for each data item inside the session using a foreach loop
    //to split the session array between the index and the content of the cell
    //for each iteration of the loop
    //store the id in a local variable $index & store the required quantity into a local variable $value
    foreach($_SESSION['basket'] as $index => $value)
    {
        $SQL = "select * from product where prodId=".$index;
        $exeSQL=mysqli_query($conn, $SQL) or die (mysql_error());
        $arrayp=mysqli_fetch_array($exeSQL);
        echo "<tr>";
        //display product price using the array of records $arrayp
        echo "<td>".$arrayp['prodName']."</td>"; 
        echo "<td>$".$arrayp['prodPrice']."</td>";
        echo "<td>".$value."</td>";
        $subtotal=$arrayp['prodPrice'] * $value;
        echo "<td>$".$subtotal."</td>";
        //total increasing by adding subtotal
        $total = $total + $subtotal;
        echo "<form action=basket.php method=post>";
        echo "<td>";
        echo "<input type=submit value='Remove' id='submitbtn'>";
        echo "</td>";
        echo "<input type=hidden name=del_prodid value=".$arrayp['prodId'].">";
        echo "</form>";
        echo "</tr>";
    }
    
}else
{
    echo "<p> Empty Basket";
}
//display total
echo "<tr>";
echo "<td colspan=4 style='text-align:right'><b> TOTAL </b></td>";
echo "<td><b>$".$total."</b></td>";
echo "<tr>";
echo "</table>";

echo "<br><p><a href='clearbasket.php'>CLEAR BASKET</a></p>";
echo "<br><p> New Homteq customers - <a href='signup.php'>Sign up</a></p>";
echo "<br><p> Returning Homteq customers - <a href='login.php'>Login</a></p>";

include("footfile.html"); //include head layout

echo "</body>";
?>
